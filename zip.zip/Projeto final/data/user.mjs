export class user {
    constructor(name, email, id){
        this.name = name
        this.email = email
        this.delete = false
        this.id = id
    }
}