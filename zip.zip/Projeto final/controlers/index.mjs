import { user } from '../data/user.mjs'

const users = []

function createUser(req, res) {
    
    const { name, email } = req.body;  
    const newUser = new user(name, email, users.length+1)
    users.push(newUser)
    return res.json(newUser);
    
}

export { createUser }