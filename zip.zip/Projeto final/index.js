import express from 'express';
var app = express();
app.use(express.json())
app.use(express.urlencoded({extended:true}))

import { router } from './routes/routes.mjs';


/* app.use((req, res, next) => {
    console.log('ola')
    next()
})  */ 
app.use(router)


app.listen(8000, function() {
    console.log('Executando na porta 8000!');
});