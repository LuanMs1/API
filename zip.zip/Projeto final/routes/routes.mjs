import { Router } from "express";
const router = Router();

import { createUser } from "../controlers/index.mjs"
router.post("/", fun, createUser);

function fun(req, res, next){
        console.log('ola')
        next()
    }


export { router }